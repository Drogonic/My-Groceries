
import Foundation


import ParseSwift



struct Post: ParseObject {
    
    // These are required by ParseObject
    var objectId: String?
    var createdAt: Date?
    var updatedAt: Date?
    var ACL: ParseACL?
    var originalData: Data?

    // Your own custom properties.

    var groceryName: String?
    var boughtDate:String?
    var expireDate: String?
    var notes:String?
    var category: String?
    var image: ParseFile?
    var user: User?
    }




